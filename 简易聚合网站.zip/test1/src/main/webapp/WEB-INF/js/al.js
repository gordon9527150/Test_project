function al() {
    console.log("你好！")
}