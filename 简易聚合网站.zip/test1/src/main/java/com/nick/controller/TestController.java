package com.nick.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestController {
    
    @RequestMapping("/index")
    public String test(){
        System.out.println("测试聚合网站！");
        return "index";
    }



}
